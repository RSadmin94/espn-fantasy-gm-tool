import "dotenv/config";
import { clerkMiddleware } from "@clerk/express";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter, createWarRoomCorsMiddleware } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { espnRefreshHandler } from "../scheduledRefresh";
import { weeklyIntelHandler } from "../weeklyIntelHandler";
import { registerAdvisorStreamRoute } from "../advisorStreamHandler";
import { registerStripeWebhook } from "../stripeWebhook";
import { registerHealthRoute } from "./healthRoute";

async function startServer() {
  const { runMigrations } = await import("../runMigrations");
  await runMigrations();

  const app = express();
  app.set("trust proxy", 1);
  const server = createServer(app);

  // Stripe webhook MUST be registered before express.json() to preserve raw body for signature verification
  registerStripeWebhook(app);

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  app.use(createWarRoomCorsMiddleware());

  app.use(clerkMiddleware());

  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );

  registerHealthRoute(app);
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  // Streaming advisor SSE endpoint — must be before Vite/static fallthrough
  registerAdvisorStreamRoute(app);
  // Scheduled job handlers — must be before Vite/static fallthrough
  app.post("/api/scheduled/espn-refresh", espnRefreshHandler);
  app.post("/api/scheduled/weekly-intel", weeklyIntelHandler);

  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = parseInt(process.env.PORT || "3000");

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
